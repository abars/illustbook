#include <stdio.h>
#include <vector>

int main(int argc,char *argv[]){
	if(argc!=3){
		printf("[usage:div.exe src.bin outdir]");
		return -1;
	}
	
	FILE *src;
	src=fopen(argv[1],"rb");
	if(src==NULL){
		printf("[error:cant open %s]",argv[1]);
		return -1;
	}
	
	int frame_no=0;
	
	printf("[begin all frame]");

	while(1){
		//Big endian read
		int size=0;
		for(int i=0;i<4;i++){
			size<<=8;
			size|=fgetc(src);
		}
		if(size==0){
			break;
		}
		
		//progress output
		printf("[%d ",frame_no);
		printf("size:%d pos:%dMB]",size,(int)ftell(src)/1024/1024);
		
		//output path
		char path[2048];
		sprintf(path,"%s/%08d.png",argv[2],frame_no);
		
		//open output file
		FILE *dest;
		dest=fopen(path,"wb");
		if(dest==NULL){
			printf("[error:cant open %s]",path);
			fclose(src);
			return -1;
		}
		
		//write jpeg data
		std::vector<unsigned char> data(size);
		fread(&data[0],size,1,src);
		fwrite(&data[0],size,1,dest);
		fclose(dest);
		
		//go next frame
		frame_no++;
	}
	
	printf("[finish all frame]");
	
	fclose(src);
}
